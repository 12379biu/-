#include "my_task.h"
#include "gpio.h"
#include <stdio.h>
#include "usart.h"
#include "adc.h"
#include "Status_Monitor.h"
#include "74HC595.h"
#include "mb.h"
#include "MyFlash_config.h"
/*�߳��� ----------------------------------------------------------------------*/


/*�߳��� ----------------------------------------------------------------------*/
class ID_Task:public TaskBase{
public:
ID_Task():TaskBase("ID_task",128,1){};
virtual void task(void *arg)
{
	while(1)
	{
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}	
};
ID_Task IDtask;

/*�߳��� ----------------------------------------------------------------------*/
class Flah_Task:public TaskBase{
public:
Flah_Task():TaskBase("Flash_task",128,1){};
virtual void task(void *arg)
{
	while(1)
	{
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}	
};
Flah_Task Flashtask;
/*�߳��� ----------------------------------------------------------------------*/
//��������
/*��λ��ͨ�����߳�*/
#if 1
class uart_Task:public TaskBase{
public:
uart_Task():TaskBase("uart_task",128,1){};
virtual void task(void *arg)
{
	usart1_init(115200);
	HC595_init();
	HC595__read_bit_init();
	HC595_open_all_locks();
	
	uint32_t x = 0;
	while(1)
	{
		x = HC595__read_scan();
		printf("0x%08X",x);
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}	
};
uart_Task uarttask;
#endif
/*end-----------------------------------------------------------------------------*/
