#include "tim.h"

void tim6_us(uint32_t us)
{
	// ʹ�� TIM6 ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	
	// �رն�ʱ��
	// void TIM_Cmd(TIM_TypeDef* TIMx, FunctionalState NewState);
	// TIM_Cmd(TIM6, DISABLE);
	TIM_Cmd(TIM6,DISABLE);
	//ʱ����Ԫ
	TIM6->CNT = 0;
	TIM6->ARR = 72 - 1;
	TIM6->PSC = 0;
	
	TIM_Cmd(TIM6,ENABLE);
	while(us--)
	{
		//�ȴ����±��λ
		while(TIM_GetFlagStatus(TIM6,TIM_FLAG_Update) == RESET);
		TIM_ClearFlag(TIM6,TIM_FLAG_Update);
	}
	TIM_Cmd(TIM6,DISABLE);
}


void tim6_ms(uint32_t ms)
{
	// ʹ�� TIM6 ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	
	// �رն�ʱ��
	// void TIM_Cmd(TIM_TypeDef* TIMx, FunctionalState NewState);
	// TIM_Cmd(TIM6, DISABLE);
	TIM_Cmd(TIM6,DISABLE);
	//ʱ����Ԫ
	TIM6->CNT = 0;
	TIM6->ARR = 1000 - 1;
	TIM6->PSC = 72 - 1;
	
	TIM_Cmd(TIM6,ENABLE);
	while(ms--)
	{
		//�ȴ����±��λ
		while(TIM_GetFlagStatus(TIM6,TIM_FLAG_Update) == RESET);
		TIM_ClearFlag(TIM6,TIM_FLAG_Update);
	}
	TIM_Cmd(TIM6,DISABLE);
}

//������status_monitor���жϴ���
void TIM7_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    // 1. ʹ��TIM7ʱ��
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
    
    // 2. ����ʱ����Ԫ
    TIM_TimeBaseInitStructure.TIM_Period = 10000 - 1;          // ��װ��ֵARR
    TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;        // Ԥ��Ƶ��PSC
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; // ���ϼ���ģʽ
    TIM_TimeBaseInit(TIM7, &TIM_TimeBaseInitStructure);
    
    // 3. ʹ�ܸ����ж�
    TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
    
    // 4. ����NVIC
    NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;            // ��ΪTIM7�ж�
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 15;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // 5. ʹ�ܶ�ʱ��
    TIM_Cmd(TIM7, ENABLE);
}
