//�����ļ���������Ӳ���ͷ�ڵ�
#include "my_queue.h"

#define DEBUG   0
//#define FREERTOS
void my_strcpy(uint8_t* dest, const uint8_t* src) {
	for (int i = 0;i < QUEUE_SIZE;i++)
		*dest++ = *src++;
}
//��������
queue_t ::queue_t(pmempools_t mp)
{
    //����ͷ�ڵ�
    this->mp = mp;
    head = (pnode_t)mp->malloc(sizeof(node_t));
    MY_ASSERT(head);
    node_num = 0;
    tail = head;
    tail->next = NULL;
    top = NULL;
}

//β�巨���
bool queue_t::enqueue(const pdata_t pdata)
{
#ifdef FREERTOS
    taskENTER_CRITICAL();
#endif
    if (mp->get_free_count() == 0)
    {
#ifdef FREERTOS
    taskEXIT_CRITICAL();
#endif
    return false;//��������
    }
        
    pnode_t node = (node_t*)mp->malloc(sizeof(node_t));
    MY_ASSERT(mp && node);//��ָ�봦��
	
	
	my_strcpy(node->data,pdata);
    node->next = NULL;
    tail->next = node;
    tail = node;
    if (node_num == 0)
        top = node;
    node_num++;
#ifdef FREERTOS
    taskEXIT_CRITICAL();
#endif
    return true;
}



//��������
void queue_t::print()
{
    uint32_t count = 0;
    pnode_t xp = head->next;
    while(xp)
    {
        count++;

        #if DEBUG
        printf("��%d���ڵ�Ϊ:%d\n",count,xp->data);
        #endif

        xp = xp->next;
    }
}

//�ͷ���������
void queue_t::clear()
{
    #ifdef FREERTOS
    taskENTER_CRITICAL();
	#endif
    MY_ASSERT(mp);//����������
    pnode_t node = head->next;
    pnode_t p = node;
    while(node)
    {
        node = node->next;
        mp->free(p);
        if (node == NULL)
            break;        
        p = node;
    }
    //ʹ���ڵ�ָ���ʼ״̬
    tail = head;
    head->next = NULL;
    top = NULL;
    node_num = 0;

    #ifdef FREERTOS
    taskEXIT_CRITICAL();
	#endif
}


/**����
 * mp:�ڴ��
 */
node_t queue_t::dequeue()
{
#ifdef FREERTOS
    taskENTER_CRITICAL();
#endif
    MY_ASSERT(mp);//����������
    pnode_t node = top;
    node_t node2 = {0};
	//mp->free_count = 0;
    if (node_num == 0)
    {
        #if DEBUG
        printf("����Ч�ڵ�");
        #endif
#ifdef FREERTOS
    taskEXIT_CRITICAL();
#endif
        return node2;
    }

    else if (node_num == 1)
    {
        top = NULL;
        head->next = NULL;
        tail = head;
    }

    else
    {
        top = top->next;
        head->next = top;
    }
    node2 = *node;
    mp->free(node);
    node_num--;
#ifdef FREERTOS
    taskEXIT_CRITICAL();
#endif
    return node2;
}


//�޸Ľڵ���Ϣ
void queue_t::node_change(uint32_t count,const pdata_t pdata)
{
    pnode_t node = head;
    if (count > node_num)
    {
        #if DEBUG
        printf("�޴˽ڵ�\n");
        #endif

        return;
    }
    while (--count)//�ҵ�ǰ�ýڵ�
    {
        node = node->next;
    }
    my_strcpy(node->data,pdata);
}

//��ѯ�ڵ���Ϣ
void queue_t::node_print(uint32_t count)
{
    pnode_t node = head;
    if (count > node_num)
    {
        #if DEBUG
        printf("�޴˽ڵ�\n");
        #endif

        return;
    }
    while (--count)//�ҵ�ǰ�ýڵ�
    {
        node = node->next;
    }
    #if DEBUG
    printf("�˽ڵ�Ϊ:%d\n",node->next->data);
    #endif
}
#ifdef BUG
bool queue_t::enqueue_ISR(pmempools_t mp,const pdata_t pdata)
{
#ifdef FREERTOS
    UBaseType_t uxSavedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();
#endif
    if (mp->get_free_count() == 0)
    {
#ifdef FREERTOS
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);
#endif
    return false;//��������
    }
        
    pnode_t node = (node_t*)mp->malloc(sizeof(node_t));
    MY_ASSERT(mp && node);//��ָ�봦��
	
	
	my_strcpy(node->data,pdata);
    node->next = NULL;
    tail->next = node;
    tail = node;
    if (node_num == 0)
        top = node;
    node_num++;
#ifdef FREERTOS
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);
#endif
    return true;
}

//�ͷ���������
void queue_t::clear_ISR(pmempools_t mp)
{
#ifdef FREERTOS
    UBaseType_t uxSavedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();
#endif
    MY_ASSERT(mp);//����������
    pnode_t node = head->next;
    pnode_t p = node;
    while(node)
    {
        node = node->next;
        mp->free(p);
        if (node == NULL)
            break;        
        p = node;
    }
    //ʹ���ڵ�ָ���ʼ״̬
    tail = head;
    head->next = NULL;
    top = NULL;
    node_num = 0;

#ifdef FREERTOS
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);
#endif
}
node_t queue_t::dequeue_ISR(pmempools_t mp)
{
#ifdef FREERTOS
    UBaseType_t uxSavedInterruptStatus = taskENTER_CRITICAL_FROM_ISR();
#endif
    MY_ASSERT(mp);//����������
    pnode_t node = top;
    node_t node2 = {0};
	//mp->free_count = 0;
    if (node_num == 0)
    {
        
        #if DEBUG
        printf("����Ч�ڵ�");
        #endif
#ifdef FREERTOS
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);
#endif
        return node2;
    }

    else if (node_num == 1)
    {
        top = NULL;
        head->next = NULL;
        tail = head;
    }

    else
    {
        top = top->next;
        head->next = top;
    }
    node2 = *node;
    mp->free(node);
    node_num--;
#ifdef FREERTOS
    taskEXIT_CRITICAL_FROM_ISR(uxSavedInterruptStatus);
#endif
    return node2;
}

#endif
//���оͲ�Ҫ������˰ɣ�ע��
//��ָ����λ�ô���һ���ڵ�
// void node_create(pmempools_t mp,plist_t list,uint32_t count,uint32_t id)
// {
//     node_t* p = list->head;
//     if (count >= list->node_num)
//     {
//         printf("�����ڵ�����or�˽ڵ�Ϊβ�ڵ�\n");
//         return;
//     }
//     //�ҵ�Ҫ�����ǰ�˽ڵ�
//     while(--count)
//     {
//         p = p->next;
//     }

//     pnode_t node = (pnode_t)my_malloc(mp,sizeof(node_t));
//     if (!node)
//     {
//         fprintf(stderr, "�޷������ڵ�,�����˳�\n");
//         exit(EXIT_FAILURE); // ��ֹ����
//     }

//     node->next = p->next;
//     p->next = node;
//     node->id = id;
//     list->node_num++;
//     printf("���ӳɹ�!ʣ�����������Ŀ:%d\n",mp->free_count);
// }
