#include "my_task.h"

#define 	Delay_ms(ms)	vTaskDelay(pdMS_TO_TICKS(ms))

/* �������Ը�ֵ */
TaskBase::TaskBase (const char * const Name,const uint16_t Size,UBaseType_t Pri):
pcName(Name),Task_Size(Size),Priority(Pri),Handler(NULL)
{
    xTaskCreate(App,pcName,Task_Size,this,Priority,&Handler);
}

/* ��������Ա�����ô��麯�� */
void TaskBase::App(void *arg)
{
    TaskBase *p = static_cast<TaskBase*>(arg);
    p->task(NULL);
}

 /* ɾ������ */
void TaskBase::deleteTask()
{
    if (Handler != NULL)
    {
        vTaskDelete(Handler);
        Handler = NULL;
    }
}


/*timers------------------------------------------------------*/
//TimBase::TimBase(const char * const Name,const TickType_t Ticks,const UBaseType_t x,void * const ID,TimerCallbackFunction_t Function)
//:pcName(Name),xTimerPeriodInTicks(Ticks),uxAutoReload(x),pvTimerID(ID),pxCallbackFunction(Function)
//{
//    Handle = xTimerCreate(
//        pcName,                // ��ʱ������
//        xTimerPeriodInTicks,     // ��ʱ������ (500ms)
//        uxAutoReload,                 // �Զ����� (������)
//        pvTimerID,                   // ��ʱ��ID
//        pxCallbackFunction ); 
//}

//BaseType_t TimBase::Start()
//{
//    if (Handle)
//        return xTimerStart(Handle,portMAX_DELAY);
//    return pdFAIL;
//}


//BaseType_t TimBase::Change(const TickType_t Ticks)
//{
//    if (Handle)
//        return xTimerChangePeriod(Handle,Ticks,portMAX_DELAY);
//    return pdFAIL;
//}

//BaseType_t TimBase::Stop()
//{
//    if (Handle) 
//        return xTimerStop(Handle, portMAX_DELAY);
//    return pdFAIL;
//}
/* end------------------------------------------------------------------ */
