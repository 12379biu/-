#include "Password.h"
#include "myflash_config.h"
#include "usart.h"
#include <stdio.h>
#include "tim.h"
#include "c_cpp.h"

/***********************************************************************************/
#include "stdlib.h"
#include <string.h>
//sha256.h
#define SHA256_BLOCK_SIZE 32 //SHA 256bits = 32Bytes

typedef struct
{
    uint8_t data[64];
    uint32_t datalen;
    unsigned long long bitlen;
    uint32_t state[8];
} sha256_ctx_t;

//api
void sha256_init(sha256_ctx_t *ctx);
void sha256_update(sha256_ctx_t *ctx, const uint8_t data[], uint32_t len);
void sha256_final(sha256_ctx_t *ctx, uint8_t hash[]);

//sha256.c
/****************************** MACROS ******************************/
#define ROTLEFT(a,b) (((a) << (b)) | ((a) >> (32-(b))))
#define ROTRIGHT(a,b) (((a) >> (b)) | ((a) << (32-(b))))

#define CH(x,y,z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x,y,z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTRIGHT(x,2) ^ ROTRIGHT(x,13) ^ ROTRIGHT(x,22))
#define EP1(x) (ROTRIGHT(x,6) ^ ROTRIGHT(x,11) ^ ROTRIGHT(x,25))
#define SIG0(x) (ROTRIGHT(x,7) ^ ROTRIGHT(x,18) ^ ((x) >> 3))
#define SIG1(x) (ROTRIGHT(x,17) ^ ROTRIGHT(x,19) ^ ((x) >> 10))

/**************************** VARIABLES *****************************/
static const uint32_t k[64] =
{
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};


static void sha256_transform(sha256_ctx_t *ctx, const uint8_t data[])
{
    uint32_t a, b, c, d, e, f, g, h, i, j, t1, t2, m[64];

    for(i = 0, j = 0; i < 16; ++i, j += 4)
    {
        m[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | (data[j + 3]);
    }
    for(; i < 64; ++i)
    {
        m[i] = SIG1(m[i - 2]) + m[i - 7] + SIG0(m[i - 15]) + m[i - 16];
    }

    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];
    f = ctx->state[5];
    g = ctx->state[6];
    h = ctx->state[7];

    for(i = 0; i < 64; ++i)
    {
        t1 = h + EP1(e) + CH(e, f, g) + k[i] + m[i];
        t2 = EP0(a) + MAJ(a, b, c);
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
}

void sha256_init(sha256_ctx_t *ctx)
{
    ctx->datalen = 0;
    ctx->bitlen = 0;
    ctx->state[0] = 0x6a09e667;
    ctx->state[1] = 0xbb67ae85;
    ctx->state[2] = 0x3c6ef372;
    ctx->state[3] = 0xa54ff53a;
    ctx->state[4] = 0x510e527f;
    ctx->state[5] = 0x9b05688c;
    ctx->state[6] = 0x1f83d9ab;
    ctx->state[7] = 0x5be0cd19;
}

void sha256_update(sha256_ctx_t *ctx, const uint8_t data[], uint32_t len)
{
    uint32_t i;

    for(i = 0; i < len; ++i)
    {
        ctx->data[ctx->datalen] = data[i];
        ctx->datalen++;
        if(ctx->datalen == 64)
        {
            sha256_transform(ctx, ctx->data);
            ctx->bitlen += 512;
            ctx->datalen = 0;
        }
    }
}

void sha256_final(sha256_ctx_t *ctx, uint8_t hash[])
{
    uint32_t i;

    i = ctx->datalen;

    // Pad whatever data is left in the buffer.
    //��仺������ʣ����κ����ݡ�
    if(ctx->datalen < 56)
    {
        ctx->data[i++] = 0x80;
        while(i < 56)
        {
            ctx->data[i++] = 0x00;
        }
    }
    else
    {
        ctx->data[i++] = 0x80;
        while(i < 64)
        {
            ctx->data[i++] = 0x00;
        }
        sha256_transform(ctx, ctx->data);
        memset(ctx->data, 0, 56);
    }

    // Append to the padding the total message's length in bits and transform.
    //����Ϣ���ܳ��ȣ���λΪ��λ�����ӵ���䲿�ֲ�����ת����
    ctx->bitlen += ctx->datalen * 8;
    ctx->data[63] = ctx->bitlen;
    ctx->data[62] = ctx->bitlen >> 8;
    ctx->data[61] = ctx->bitlen >> 16;
    ctx->data[60] = ctx->bitlen >> 24;
    ctx->data[59] = ctx->bitlen >> 32;
    ctx->data[58] = ctx->bitlen >> 40;
    ctx->data[57] = ctx->bitlen >> 48;
    ctx->data[56] = ctx->bitlen >> 56;
    sha256_transform(ctx, ctx->data);

    // Since this implementation uses little endian byte ordering and SHA uses big endian,
    // reverse all the bytes when copying the final state to the output hash.
    //���ڴ�ʵ��ʹ��С�����ֽ����򣬶�SHAʹ�ô����
    //����ڽ�����״̬���Ƶ����ɢ��ʱ������ת�����ֽڡ�
    for(i = 0; i < 4; ++i)
    {
        hash[i]      = (ctx->state[0] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 4]  = (ctx->state[1] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 8]  = (ctx->state[2] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 12] = (ctx->state[3] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 16] = (ctx->state[4] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 20] = (ctx->state[5] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 24] = (ctx->state[6] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 28] = (ctx->state[7] >> (24 - i * 8)) & 0x000000ff;
    }
}
/***********************************************************************/
//test
void log_hex(char *head, uint8_t *data, uint8_t len)
{
    uint8_t i;
    printf("%s:", head);
    for(i = 0; i < len; i++)
    {
        printf("%02X ", data[i]);
    }
    printf("\r\n");
}

//���뱾
uint8_t shuffled_array[256] = {
    0x49, 0xA8, 0x8B, 0xC7, 0x92, 0x70, 0xD4, 0xC8, 0x4A, 0x71, 0x53, 0xA0, 0x05, 0x32, 0x60, 0xBA, 
    0xB6, 0x9C, 0xFA, 0x18, 0xED, 0x5F, 0x11, 0xF6, 0x9E, 0xAE, 0x68, 0xAF, 0x2F, 0xA7, 0xDB, 0xAA, 
    0x23, 0x47, 0x1F, 0xA5, 0x2D, 0xB1, 0x2B, 0x94, 0x57, 0x0B, 0xCF, 0x3F, 0xD0, 0x75, 0x37, 0x39, 
    0xC4, 0x07, 0xB3, 0xF7, 0x65, 0x93, 0x76, 0x29, 0x78, 0x0A, 0xC0, 0x0F, 0xF9, 0xAD, 0x6F, 0x61, 
    0x04, 0xB2, 0x62, 0xCD, 0xEE, 0x2E, 0xFF, 0x85, 0x3D, 0x82, 0x73, 0x15, 0x64, 0xF2, 0x95, 0x00,
    0x28, 0x13, 0x7D, 0xA2, 0xE2, 0x77, 0x4E, 0x17, 0x56, 0xB7, 0x3C, 0xBC, 0xE9, 0xDE, 0x38, 0x99, 
    0x87, 0xB5, 0x58, 0x9A, 0xE4, 0x2A, 0xB4, 0xAC, 0x51, 0x97, 0x3E, 0x8F, 0x44, 0x91, 0xA6, 0x79,
    0xE1, 0x09, 0x43, 0x6C, 0x0C, 0xDF, 0x7A, 0x22, 0xE6, 0xE3, 0xAB, 0x66, 0xA1, 0x30, 0x8A, 0x74,
    0xBE, 0x50, 0x5D, 0xB9, 0x14, 0x52, 0xEC, 0xCE, 0x96, 0x0E, 0xE5, 0xCC, 0x55, 0xA4, 0x31, 0xF0, 
    0xD5, 0x5C, 0x5E, 0xC9, 0xD9, 0x26, 0x2C, 0x9B, 0x54, 0xD8, 0xC2, 0xDA, 0xCA, 0x48, 0xF3, 0xE8,
    0x4D, 0x83, 0xF1, 0x46, 0x1A, 0xF4, 0x20, 0xBB, 0xB8, 0x1B, 0x8D, 0x1E, 0xFD, 0x7F, 0x1D, 0x1C, 
    0x25, 0x89, 0x5A, 0x19, 0xD6, 0x63, 0x4F, 0x69, 0x06, 0x90, 0x35, 0xFC, 0xC3, 0x9D, 0x12, 0xA9,
    0x3A, 0x9F, 0xD3, 0x40, 0x81, 0x88, 0x08, 0x86, 0xF5, 0x33, 0xEB, 0xEA, 0x36, 0x80, 0x98, 0xBF, 
    0x7C, 0x03, 0xA3, 0x0D, 0xC1, 0x72, 0x3B, 0x24, 0xD1, 0xFB, 0x5B, 0xB0, 0x8C, 0xE0, 0xDD, 0xDC,
    0xD2, 0xC6, 0x6E, 0x84, 0xC5, 0xFE, 0x02, 0x01, 0x59, 0x6A, 0x10, 0xEF, 0xF8, 0x34, 0x42, 0x21,
    0x41, 0x4B, 0x4C, 0x27, 0x7E, 0x16, 0xCB, 0xBD, 0xD7, 0x8E, 0x7B, 0x67, 0x6D, 0x45, 0xE7, 0x6B
};

void change(uint8_t* str)
{
    for (int i = 0;i < 32;i++)
    {
        str[i] = shuffled_array[str[i]];
    }
}


/***********************************************************************************/
extern volatile uint16_t die_tim;

__IO uint8_t UID[31] = {
	//uid
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	// h    u    a    q    i    n    g    y    u    a    n
	0x68, 0x75, 0x61, 0x71, 0x69, 0x6E, 0x67, 0x79, 0x75, 0x61, 0x6E,
	// j    i    a    n        2    5    0    3
	0x6A, 0x69, 0x61, 0x6E, 0x32, 0x35, 0x30, 0x33};

/*
*((__IO uint32_t*)0x1FFFF7E8);
*((__IO uint32_t*)0x1FFFF7E8 + 1);
*((__IO uint32_t*)0x1FFFF7E8 + 2);*���ļ����ڼ�������֤
*
*/
extern volatile uint16_t die_tim;
//����uid + "huaqingyuanjian2503"--31�ֽ�
uint8_t password1[32] = {0};

//����
uint8_t password2[32] = {0};

//����flash�б���λ���洢�İ���
void get_password1(void)
{
		// ��4�ֽ�һ���ȡ��32�ֽڹ�8�飩
	for (uint8_t i = 0; i < 8; i++)
	{
		// ��ȡ4�ֽ��֣��ڲ��Ѵ���С�˴洢��
		uint32_t data = *(uint32_t *)(ADDR_PassWord + i*4);
		
		// ���ֽڲ�ֲ�����ȷ˳��洢
		password1[i*4 + 0] = (data >> 24) & 0xFF;  // ���ֽ�
		password1[i*4 + 1] = (data >> 16) & 0xFF;
		password1[i*4 + 2] = (data >> 8) & 0xFF;
		password1[i*4 + 3] = data & 0xFF;          // ���ֽ�
	}
}

//��UIDת��Ϊ����
void get_password2(void)
{
    sha256_ctx_t sha;
	sha256_init(&sha);
    sha256_update(&sha,(uint8_t*) UID, sizeof(UID));
	sha256_final(&sha, password2);
	change(password2);
	
}

//����UID
void UID_init(void)
{

	// ��4�ֽ�һ���ȡ��12�ֽڹ�3�飩
	for (uint8_t i = 0; i < 3; i++)
	{
		// ��ȡ4�ֽ��֣��ڲ��Ѵ���С�˴洢��
		uint32_t data = *(uint32_t *)(0x1FFFF7E8 + i*4);
		
		// ���ֽڲ�ֲ�����ȷ˳��洢
		UID[i*4 + 0] = (data >> 24) & 0xFF;  // ���ֽ�
		UID[i*4 + 1] = (data >> 16) & 0xFF;
		UID[i*4 + 2] = (data >> 8) & 0xFF;
		UID[i*4 + 3] = data & 0xFF;          // ���ֽ�
	}
	
}


void MCU_Unlock(void)
{
	TIM7_Init();
	usart1_init(115200);
	//UID��ʼ��-->�ɹ�
	UID_init();
	//printf("OK");
	//log_hex("UID:", (uint8_t*)UID, 31);
	//���ɰ���
	get_password1();
	//log_hex("password1:", (uint8_t*)password1, 32);
	get_password2();//-->���ɳɹ�
	//log_hex("password2:", (uint8_t*)password2, 32);
	//�Ƚ������Ƿ���ȷ���ϵ��ȡ��ɱʱ��
	if (memcmp(password1,password2,32) == 0)
	{
		//������λ��,ͨѶģʽ
		printf("OK");
		uint16_t temp = *(__IO uint16_t*)PAGE_127_ADDR;
		//ʱ���Ѽ�¼���ȡ
		if (temp != 0xffff)
			die_tim = temp;
		return;
	}
	uint8_t flag = 1;
	while(1)
	{
		if (flag)
		{
			//��������
			for (uint8_t i = 0;i < 31;i++)
				printf("%02x",UID[i]);
			
			//���ӣ����հ���
			flag = 0;
		}
		if(check())//����ͨ��
			return;		
		tim6_ms(1000);
	}
	
}
/*-end---------------------------------------------------------------*/
