#include "GPIO.h"

/**
* ��ʼ����ɫС��
* �������  �ߵ�ƽ
*/
GPIO_t::GPIO_t(GPIO_TypeDef* gpio_port, uint16_t pin,FlagStatus Pin_State)
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};
	GPIOx = gpio_port;
	GPIO_Pin = pin;
	if (GPIOx == GPIOA)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	else if (GPIOx == GPIOB)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	else if (GPIOx == GPIOC)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOx, &GPIO_InitStructure);

	Pin_State == SET ? GPIO_SetBits(GPIOx,pin) : GPIO_ResetBits(GPIOx,pin);
}

/*
* Ϩ��Ŀ��С�ƣ��ߵ�ƽ
*/
void GPIO_t::Hight()
{
	GPIO_SetBits(GPIOx,GPIO_Pin);
}

/*
* ����Ŀ��С�ƣ��͵�ƽ
*/
void GPIO_t::Low()
{
	GPIO_ResetBits(GPIOx,GPIO_Pin);
}

/*
* ��תĿ��С��
*/
void GPIO_t::Toggle()
{
	uint8_t state = GPIO_ReadOutputDataBit(GPIOx,GPIO_Pin);
	state ? GPIO_ResetBits(GPIOx,GPIO_Pin) : GPIO_SetBits(GPIOx,GPIO_Pin);
}
