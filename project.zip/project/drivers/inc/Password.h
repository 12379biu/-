#ifndef PASSWORD_H
#define PASSWORD_H

#include "stm32f10x.h"

#ifdef __cplusplus
extern "C"{
#endif

void MCU_Unlock(void);

#ifdef __cplusplus
}
#endif
#endif
