#ifndef GPIO_H
#define GPIO_H


#ifdef __cplusplus
extern "C"{
#endif
#include "stm32f10x.h"
	
class GPIO_t{
	private:
		GPIO_TypeDef* GPIOx;
		uint16_t GPIO_Pin;
	public:
		GPIO_t(GPIO_TypeDef* gpio_port, uint16_t pin,FlagStatus Pin_State);
		void Hight();
		void Low();
		void Toggle();
		inline uint8_t Read_Pin(uint16_t pin){return GPIO_ReadOutputDataBit(GPIOx,GPIO_Pin);}
};

#ifdef __cplusplus
}
#endif
#endif
