#ifndef __USART_H_
#define __USART_H_

#include "stm32f10x.h"
#ifdef __cplusplus
extern "C"{
#endif
	
void usart1_init(uint32_t baudrate);
int usart1_putchar(int ch);
int usart1_getchar(void);
	
#ifdef __cplusplus
}
#endif
#endif  // __USART_H_
