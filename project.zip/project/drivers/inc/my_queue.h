#ifndef MY_QUEUE_H
#define MY_QUEUE_H

#ifdef __cplusplus 

extern "C"{
#endif

#include "mempool.h"
#include "my_assert.h"

const uint8_t QUEUE_SIZE = 33;

typedef uint8_t data_t,*pdata_t;
//�����ڵ�ṹ��
typedef struct node{
    data_t data[QUEUE_SIZE];
    struct node *next;
    
}node_t,*pnode_t;

class queue_t{
private:
    pmempools_t mp;
    node_t *top;
    node_t *head;
    node_t *tail;
    uint32_t node_num;//�ڵ���
public:
    queue_t(pmempools_t mp);
    bool enqueue(const pdata_t pdata);
    bool enqueue_ISR(const pdata_t pdata);
    void print();
    void clear();
    void clear_ISR();
    node_t dequeue();
    node_t dequeue_ISR();
    void node_change(uint32_t count,const pdata_t pdata);
    void node_print(uint32_t count);
    uint32_t get_num(){return node_num;}
};

typedef queue_t*  pqueue_t;

#ifdef __cplusplus 
}
#endif

#endif
