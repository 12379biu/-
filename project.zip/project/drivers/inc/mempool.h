#ifndef MEMPOOL_H
#define MEMPOOL_H

#ifdef __cplusplus 
extern "C"{
#endif

#include <stdio.h>
#include <string.h>
#include "my_assert.h"

class mempools_t{
private:
    size_t memory_size;//�ܿռ䳤��
    int block_size; //һ��ռ���ռ���ڴ�
    int free_count; //ʣ��ռ����
    void *mem;      
    char *ptr;      //��ռ�ĵ�ַ
public:
    mempools_t(size_t size);
    void *malloc(size_t size);
    void mempool_free();
    void free(void *p);
    int get_free_count(){return free_count;}
	int get_block_size(){return block_size;}
	int get_memory_size(){return memory_size;}
};

typedef mempools_t* pmempools_t;

/*-------------------------------------------------------------*/

class datamempools_t{
private:
    size_t memory_size;//�ܿռ䳤��
    int block_size; //һ��ռ���ռ���ڴ�
    int free_count; //ʣ��ռ����
    void *mem;      
    char *ptr;      //��ռ�ĵ�ַ
public:
    datamempools_t(size_t size);
    void *malloc(size_t size);
    void mempool_free();
    void free(void *p);
    int get_free_count(){return free_count;}
	int get_block_size(){return block_size;}
	int get_memory_size(){return memory_size;}
};

typedef datamempools_t* pdatamempools_t;
#ifdef __cplusplus 
}

#endif
#endif
