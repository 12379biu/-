#ifndef __SYSTICK_H_
#define __SYSTICK_H_

#include "stm32f10x.h"
#ifdef __cplusplus
extern "C"{
#endif
void systick_delay_ms(uint32_t ms);
void systick_delay_us(uint32_t us);

#ifdef __cplusplus
}
#endif
#endif  // __SYSTICK_H_
