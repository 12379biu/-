#ifndef TIM_H
#define TIM_H

#include "stm32f10x.h"

#ifdef __cplusplus
extern "C"{
#endif

void tim6_us(uint32_t us);
void tim6_ms(uint32_t ms);
void TIM7_Init(void);

#ifdef __cplusplus
}
#endif
#endif
