#ifndef C_CPP_H
#define C_CPP_H

#include "stm32f10x.h"

#ifdef __cplusplus
extern "C"{
#endif
	
uint8_t check(void);

#ifdef __cplusplus
}
#endif
#endif
